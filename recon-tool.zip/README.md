# recon-tool

A lightweight, modular reconnaissance CLI built for the ITSOLERA PVT LTD Summer Internship — Offensive Security (Tool Development) task. It automates the initial information-gathering phase of an authorized penetration testing engagement: WHOIS, DNS enumeration, subdomain discovery, port scanning, banner grabbing, and basic technology fingerprinting, all rolled into one report.

## ⚠️ Authorized use only

This tool performs active scanning (port scans, banner grabs, HTTP requests). Only run it against domains/hosts you own or have explicit written authorization to test. `example.com` is reserved by IANA for documentation and testing and is safe to use while learning the tool.

## Features

| Phase | Module | Flag | Description |
|---|---|---|---|
| Passive | WHOIS | `--whois` | Registrar, creation/expiry dates, name servers, status |
| Passive | DNS enumeration | `--dns` | A, AAAA, MX, TXT, NS, SOA, CNAME records |
| Passive | Subdomain enumeration | `--subdomains` | Pulls from crt.sh (cert transparency) + AlienVault OTX passive DNS, resolves IPs |
| Active | Port scan | `--ports` | Threaded TCP-connect scan over common ports (or wrap real `nmap` with `--use-nmap`) |
| Active | Banner grabbing | `--banners` | Reads service banners on open ports found by `--ports` |
| Active | Tech detection | `--tech` | Fingerprints CMS/framework/server via headers + HTML signatures |
| Reporting | — | `--format txt\|html` | Timestamped report with resolved IPs |

Each module runs independently and is callable via its own flag, or all together with `--all`.

## Installation

```bash
git clone <your-repo-url>
cd recon-tool
pip install -r requirements.txt
```

Optional: install `nmap` on your system if you want to use `--use-nmap` instead of the built-in socket scanner.

## Usage

```bash
# Run everything, write a .txt report
python main.py example.com --all

# Just passive recon
python main.py example.com --whois --dns --subdomains

# Active recon only, using real nmap, verbose
python main.py example.com --ports --use-nmap --banners -vv

# HTML report to a custom path
python main.py example.com --all --format html -o reports/example_report.html
```

### CLI flags

```
positional arguments:
  domain                Target domain, e.g. example.com

Passive recon:
  --whois               Run WHOIS lookup
  --dns                 Run DNS enumeration (A, MX, TXT, NS, ...)
  --subdomains          Run subdomain enumeration (crt.sh, OTX)
  --no-resolve          Skip resolving subdomains to IPs

Active recon:
  --ports               Run port scan
  --use-nmap            Use system nmap binary instead of socket scan
  --banners             Grab banners on open ports (requires --ports)
  --tech                Detect web technologies

  --all                 Run every module

Output:
  --format {txt,html}   Report format (default: txt)
  -o, --output          Output report file path

  -v, --verbose         Increase verbosity (-v info, -vv debug)
```

## Project structure

```
recon-tool/
├── main.py                  # CLI entrypoint (argparse)
├── modules/
│   ├── whois_lookup.py
│   ├── dns_enum.py
│   ├── subdomain_enum.py
│   ├── port_scan.py
│   ├── banner_grab.py
│   └── tech_detect.py
├── report/
│   └── generator.py         # txt/html report builder
├── sample_reports/          # example output for example.com
├── requirements.txt
├── Dockerfile
└── README.md
```

## Sample report

See `sample_reports/example.com_report.txt` and `sample_reports/example.com_report.html` for example output. Some fields (WHOIS, crt.sh) may show as failed in network-restricted environments — that's expected if outbound access to those services is blocked by a firewall/proxy; the modules degrade gracefully and continue rather than crashing.

## Docker

```bash
docker build -t recon-tool .
docker run --rm -v $(pwd)/reports:/app/reports recon-tool example.com --all -o reports/report.txt
```

## Notes on design choices

- **Socket-based port scan by default** so the tool has zero external dependency on the `nmap` binary being installed; `--use-nmap` is available for more thorough/stealthy scanning when it is.
- **Passive subdomain sources only** (crt.sh, OTX) — no active brute-forcing/wordlist guessing against the target's DNS, keeping default behavior conservative.
- **Every module returns a uniform `{module, target, success, data|error}` dict**, so the report generator and CLI don't need module-specific logic and new modules are easy to bolt on.
- **Logging via the standard `logging` module** with `-v`/`-vv` verbosity flags rather than print statements, so output is suppressible/redirectable in automation.

## Disclaimer

Built for educational purposes as part of an internship task. The author and ITSOLERA PVT LTD are not responsible for misuse of this tool.
